<?php
  define("SERVIDOR","mysql:dbname=fronter6_estancia;host=localhost");
  define("USUARIO","fronter6_216030256");
  define("PASSWORD","alan1346790");
?>
