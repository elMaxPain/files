<?php
class Principal
{
    function __construct()
    {
        
    }
}
?>