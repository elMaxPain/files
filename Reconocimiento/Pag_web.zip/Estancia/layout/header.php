<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <link rel="stylesheet" href="https://juguetrixs.com/css/splash.min.css">
</head>
<header class="header">
<div class="cont-100b bkbb wh flex">
    <h1 class="sans">HEADER</h1>
</div>
</header>
<body>
    
</body>
</html>