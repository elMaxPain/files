<?php
require_once("index.struct.php");
Init();//Se carga la function Principal
?>
    <?php
        if($tipo=="Acerca")
        {
            ?>
            <header class="header">
                <div class="cont-100 flex-f" id="header">
                    <div class="cont-35 mr-auto pad12">
                        <img src="http://frontera2019.com.mx/Estancia/public/image/upp.png" alt="" class="img-logo">
                    </div>
                    <div class="cont-35 mr-auto pad12"></div>
                    <div class="cont-50 pad12 mr-auto">
                        <a href="" class="wh apple text-d pad12 px22"></a>
                        <a href="../Estancia" class="wh apple text-d pad12 px22">Inicio</a>
                        <a href="" class="wh apple text-d pad12 px22">Contactanos</a>
                        <a href="Registro" class="wh apple text-d pad6 px22 button2 radius-total">Iniciar Sesion</a>
                    </div>
                </div>
            </header>
            <br><br><br><br><br>
            <body class="fondo3">
                <br><br><br><br>
                <br>
                <center>
                    <hr class="miniline-yel">
                </center>
                <br>
                <h1 class="cen apple wh px36 bold">ACERCA</h1>
                <br><br><br><br><br><br><br><br><br>
                <hr class="line-yel">
                <div class="cont-100 bksil">
                    <br><br><br><br><br><br>
                    <center><hr class="miniline-sil"></center>
                    <br>
                    <h1 class="varela cen px28">USAR NUESTRA WEB</h1>
                    <p class="varela cen px22 silbla">Algunos aspectos importantes en la aplicacion de las pruebas</p>
                    <div class="cont-80 mr-auto flex">
                        <div class="cont-35 mr-12 bkw pointer dis">
                            <br>
                            <center><img src="http://frontera2019.com.mx/Estancia/public/image/limpio.svg" alt="" class="img-sprash"></center>
                            <p class="px22 cen apple">Espacios Limpios</p>
                            <br>
                            <p class="px17 cen apple">La pruebas se realizan en espacios limpios y esterilizados, asi prevenimos contaminacion de sustancias.</p>
                            <br>
                        </div>
                        <div class="cont-35 mr-12 bkw pointer dis">
                        <br>
                            <center><img src="http://frontera2019.com.mx/Estancia/public/image/micro.svg" alt="" class="img-sprash"></center>
                            <p class="px22 cen apple">Analisis Seguros</p>
                            <br>
                            <p class="px17 cen apple">Las Muestras y los resultados son analizados, para demostrar un resultado eficiente.</p>
                            <br>
                        </div>
                        <div class="cont-35 mr-12 bkw pointer dis">
                        <br>
                            <center><img src="http://frontera2019.com.mx/Estancia/public/image/tubo.svg" alt="" class="img-sprash"></center>
                            <p class="px22 cen apple">Mustras Seguras</p>
                            <br>
                            <p class="px17 cen apple">La Muestras que se daran a probar, son 100% seguras y previamente utilizadas, para la seguridad de los usuarios.</p>
                            <br>
                        </div>
                    </div>
                    
                    <div class="cont-80 mr-auto flex">
                        <div class="cont-35 mr-12 bkw pointer dis">
                            <br>
                            <center><img src="http://frontera2019.com.mx/Estancia/public/image/pizarra.svg" alt="" class="img-sprash"></center>
                            <p class="px22 cen apple">Aplicantes Profesionales</p>
                            <br>
                            <p class="px17 cen apple">Las muestras son aplicadas por personal verificado y especializado en el area de muestreo.</p>
                            <br>
                        </div>
                        <div class="cont-35 mr-12 bkw pointer dis">
                        <br>
                            <center><img src="http://frontera2019.com.mx/Estancia/public/image/grafico.svg" alt="" class="img-sprash"></center>
                            <p class="px22 cen apple">Datos Analizados</p>
                            <br>
                            <p class="px17 cen apple">Los datos registrados son analizados para determinar los resultados finales de cada usuario.</p>
                            <br>
                        </div>
                        <div class="cont-35 mr-12 bkw pointer dis">
                        <br>
                            <center><img src="http://frontera2019.com.mx/Estancia/public/image/proteger.svg" alt="" class="img-sprash"></center>
                            <p class="px22 cen apple">Datos Seguros</p>
                            <br>
                            <p class="px17 cen apple">Tus datos estaran seguros en todo momento, el iniciar a la aplicacion es de lo mas anonimo.</p>
                            <br>
                        </div>
                    </div>
                </div>
                <div class="cont-100 bkw">
                    <br><br><br><br><br><br><br><br>
                    <center>
                        <hr class="miniline-sil">
                    </center>
                    <h1 class="px36 cen varela">Informacion</h1>
                    <p class="varela cen px22 silbla">Algo de informacion adicional</p>
                    <br><br><br><br>
                    <div class="cont-75 mr-auto flex">
                        <div class="cont-50 mr-12">
                            <img src="http://frontera2019.com.mx/Estancia/public/image/laboratorio.jpg" alt="" class="img-completes">
                        </div>
                        <div class="cont-50 mr-12">
                             <p class="px22 varela cen">Informacion Adicional</p>
                             <p class="px16 varela cen">
                                 Aqui se dara una descripcion mas detallada sobre las pruebas y los obteivos de ellas, se pondra un texto
                                 de prueba por lo pronto.
                                 <br><br> Lorem ipsum dolor sit amet, homero erroribus in cum. Cu eos scaevola probatus. Nam atqui intellegat ei, sed ex graece essent delectus. Autem consul eum ea. Duo cu fabulas nonumes contentiones, nihil voluptaria pro id. Has graeci deterruisset ad, est no primis detracto pertinax, at cum malis vitae facilisis.

                                 <br><br> Dicam diceret ut ius, no epicuri dissentiet philosophia vix. Id usu zril tacimates neglegentur. Eam id legimus torquatos cotidieque, usu decore percipitur definitiones ex, nihil utinam recusabo mel no. Dolores reprehendunt no sit, quo cu viris theophrastus. Sit unum efficiendi cu.
                             </p>
                        </div>
                    </div>
                </div>
            </body>
            <?php
        }
        else
        {
            ?>
            <header class="header">
                <div class="cont-100 flex-f" id="header">
                    <div class="cont-35 mr-auto pad12">
                        <img src="http://frontera2019.com.mx/Estancia/public/image/upp.png" alt="" class="img-logo">
                    </div>
                    <div class="cont-35 mr-auto pad12"></div>
                    <div class="cont-50 pad12 mr-auto">
                        <a href="" class="wh apple text-d pad12 px22"></a>
                        <a href="Acerca" class="wh apple text-d pad12 px22">Acerca</a>
                        <a href="" class="wh apple text-d pad12 px22">Contactanos</a>
                        <a href="Registro" class="wh apple text-d pad6 px22 button2 radius-total">Iniciar Sesion</a>
                    </div>
                </div>
            </header>
            <br><br><br><br><br>
                <body class="fondo">
                    <br><br><br><br><br><br>
                   <center>
                        <h1 class="px50 anton wh">MUESTRAS DE CONCENTRACIONES</h1>
                        <p class="apple px22 wh">Conoce acerca de las diferentes pruebas que se llevan a cabo</p>
                        <br><br>
                        <button class="yellow cont-35 px22 wh apple mr-auto radius-total button">Conocer</button>
                    </center>
                    <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
                    <div class="cont-100 bkblas flex">
                        <div class="cont-35 mr-auto">
                            <center>
                                <img src="http://frontera2019.com.mx/Estancia/public/image/seguro.svg" alt="" class="miniimage">
                                <br><br>
                                <p class="px20 yel apple">Tu infromacion segura</p>
                                <p class="px17 wh apple">Tu informacion estara segura en todo momento</p>
                            </center>
                        </div>
                        <div class="cont-35 mr-auto">
                            <center>
                                <img src="http://frontera2019.com.mx/Estancia/public/image/lsw.png" alt="" class="miniimage">
                                <br><br>
                                <p class="px20 yel apple">Pruebas rapidas y seguras</p>
                                <p class="px17 wh apple">Realiza cada una de las pruebas en tiempo real</p>
                            </center>
                        </div>
                        <div class="cont-35 mr-auto">
                            <center>
                                <img src="http://frontera2019.com.mx/Estancia/public/image/reww.png" alt="" class="miniimage">
                                <br><br>
                                <p class="px20 yel apple">Completa las pruebas</p>
                                <p class="px17 wh apple">Completa cada prueba y ve tu avance en el menu</p>
                            </center>
                        </div>
                    </div>
                   <div class="bkw cont-100">
                        <br><br><br><br><br><br>
                        <center><hr class="miniline cen"></center>
                        <br>
                        <h1 class="cen varela px36">Algunas Pruebas</h1>
                        <p class="px22 apple sil cen">Algunas de las pruebas que se realizaran</p>
                        <br><br><br>
                        <div class="cont-100b flex-f">
                            <div class="cont-35b border mr-12 pointer opac" id="card1">
                                <div class="contenedor">
                                    <img src="http://frontera2019.com.mx/Estancia/public/image/imagen-2.jpg" alt="" class="imagen-card">
                                </div>
                                <br>
                                <div class="cont-75 mr-auto">
                                    <p class="px16 apple sil">Categoria</p><br>
                                    <p class="px22 varela ">Muestreo de Preferencia</p>
                                    <p class="px17 varela cen jus">Esta prueba se realiza mediante pruebas que consisten en beber 2 pruebas las cuales tendran diferentes concentraciones, el usuario debera determinar cual es la concentracion mas fuerte.</p>
                                    <br>
                                    <div class="cont-50 flex-f">
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 sil">★</p>
                                        <p class="px20 sil">★</p>
                                        <p class="px16 mr-2 sil apple">(180)</p>
                                    </div>
                                    <hr>
                                    <div class="cont-100 flex-f">
                                        <div class="cont-35 mr-auto flex-f">
                                            <p class="px20 varela mr-2 sil"> &#9719;</p>
                                            <p class="px14 varela mr-6 sil">45min</p>
                                        </div>
                                        <div class="cont-15 mr-auto"></div>
                                        <div class="cont-50 mr-auto">
                                            <button onclick="location.href='https://frontera2019.com.mx/Estancia/Registro'" class="button-ini pad8 pointer pur radius-total px22 bkw  cen ">Iniciar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="cont-35b border mr-12 pointer shad" id="card2">
                                <div class="contenedor">
                                    <img src="http://frontera2019.com.mx/Estancia/public/image/imagen-1.jpg" alt="" class="imagen-card">
                                </div>
                                <br>
                                <div class="cont-75 mr-auto">
                                    <p class="px16 apple sil">Categoria</p><br>
                                    <p class="px22 varela ">Muestreo de Intencidad</p>
                                    <p class="px17 varela cen jus">Esta prueba se realiza al probar una sustancia y determinar que tan fuerte es la sustancia o que tan debil es esta misma.</p>
                                    <br><br><br>
                                    <div class="cont-50 flex-f">
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px16 mr-2 sil apple">(500)</p>
                                    </div>
                                    <hr>
                                    <div class="cont-100 flex-f">
                                        <div class="cont-35 mr-auto flex-f">
                                            <p class="px20 varela mr-2 sil"> &#9719;</p>
                                            <p class="px14 varela mr-6 sil">30min</p>
                                        </div>
                                        <div class="cont-15 mr-auto"></div>
                                        <div class="cont-50 mr-auto">
                                            <button onclick="location.href='https://frontera2019.com.mx/Estancia/Registro'" class="button-ini pad8 pointer pur radius-total px22 bkw  cen ">Iniciar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="cont-35b border mr-12 pointer opac" id="card3">
                                <div class="contenedor">
                                    <img src="http://frontera2019.com.mx/Estancia/public/image/imagen-3.jpg" alt="" class="imagen-card">
                                </div>
                                <br>
                                <div class="cont-75 mr-auto">
                                    <p class="px16 apple sil">Categoria</p><br>
                                    <p class="px22 varela ">Analisis de Sencibilidad</p>
                                    <p class="px17 varela cen jus">Esta prueba se llevara a cabo con un participante, y se le daran diferentes muestras, el participante debera determinar que tan fuerte es la sustancia, hasta haber completado un total de 7 aciertos.</p>
                                    <br>
                                    <div class="cont-50 flex-f">
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 yellows">★</p>
                                        <p class="px20 sil">★</p>
                                        <p class="px16 mr-2 sil apple">(360)</p>
                                    </div>
                                    <hr>
                                    <div class="cont-100 flex-f">
                                        <div class="cont-50 mr-auto flex-f">
                                            <p class="px20 varela mr-2 sil"> &#9719;</p>
                                            <p class="px14 varela mr-6 sil">1hr 45min</p>
                                        </div>
                                        
                                        <div class="cont-50 mr-auto">
                                            <button onclick="location.href='https://frontera2019.com.mx/Estancia/Registro'" class="button-ini pad8 pointer pur radius-total px22 bkw  cen ">Iniciar</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <br><br><br>
                   </div>
                   <div class="fondo2 cont-100 ">
                        <br><br><br><br><br>
                        <div class="bkblas aviso">
                            <br>
                            <h1 class="wh varela px24 pad12">Disfruta de una comunidad de Participantes!</h1>
                            <p class="wh varela px16 pad12 jus">Ius cu tamquam persequeris, eu veniam apeirian platonem qui, id aliquip voluptatibus pri. Ei mea primis ornatus disputationi. Menandri erroribus cu per, duo solet congue ut.</p>
                            <br>
                            <button class="button cont-35 bkbb wh radius-total varela px16">Muy pronto</button>
                        </div>
                        <br><br><br><br><br><br><br><br><br><br><br>
                        <br><br><br><br><br>
                        <br><br><br><br><br>
                   </div>
                   
                </body>
            
            <?php
        }
    ?>
    
<div class="cont-100 bkbla footer">
        <br><br><br><br><br><br>
        <div class="cont-75 mr-auto flex-f">
            <div class="cont-50 mr-auto">
                <img src="https://frontera2019.com.mx/Estancia/public/image/upp.png" alt="" class="img-logo"><br><br>
                <p class="wh apple">Mea nibh meis philosophia eu. Duis legimus efficiantur ea sea. Id placerat tacimates definitionem sea, prima quidam vim no. Duo nobis persecuti cu. Nihil facilisi indoctum an vix, ut delectus expetendis vis.</p>
            </div>
            <div class="cont-35 mr-auto">
                <br><br>
                <h1 class="px22 wh cen apple">LINKS</h1><br>
                <center>
                <a href="../Estancia" class="wh apple cen text-d pad2">Inicio</a><br><br>
                <a href="Acerca" class="wh apple cen text-d pad2">Acerca</a><br><br>
                <a href="Registro" class="wh apple cen text-d pad2">Registrar</a><br><br>
                <a href="" class="wh apple cen text-d pad2">Contacto</a><br><br>
                </center>
            </div>
            <div class="cont-35 mr-auto">
                <h1 class="wh px22 cen apple">CONTACTANOS</h1>
                <br><br>
                <div class="flex-f">
                    <img src="https://frontera2019.com.mx/Estancia/public/image/tel.svg" alt="" class="icono mr-12">
                    <p class="wh apple mr-12">469 209 11 23</p>
                </div><br>
                <div class="flex-f">
                    <img src="https://frontera2019.com.mx/Estancia/public/image/mail.svg" alt="" class="icono mr-12">
                    <p class="wh apple mr-12">upp@uppenjamo.edu.mx</p>
                </div>
            </div>
        </div>
        <hr class="line">
        <br><br>
        <div class="cont-75 mr-auto">
            <p class="cen px22 apple wh">©Uppenjamo</p>
        </div>
        <br><br>
    </div>