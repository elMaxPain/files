<?php
if(isset($_POST['prueba']))
{
    $correos = ['oscar.rivera@busman.com.mx', 'maria.rosales@busman.com.mx', 'maria.guerrero@busman.com.mx', 'alan.guzman@busman.com.mx'];
    
    
    for($i=0; $i<count($correos); $i++)
    {
        $from = "support@busman.com.mx";
        $correo=$correos[$i];
        $subject = "Soporte";
        $cabeceras2 = "MIME-Version: 1.0" . "\r\n";
        $cabeceras2 .= "Content-type: text/html; charset=utf-8" . "\r\n";
        $cabeceras2 .= "From: ".$from;
        $message  = "<html><body>";
        $message .= "<link rel='stylesheet' href='https://internos.busman.com.mx/reporte/public/css/style.css'>";
    
        $message .= "prueba: ".$i;
        if(mail($correo,$subject,$message,$cabeceras2))
        {
            echo "enviado";
        }
        else 
        {   
            echo "rechazado";
        }
    }
}

