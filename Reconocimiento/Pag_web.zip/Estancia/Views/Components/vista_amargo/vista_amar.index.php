<?php
require_once("vista_amar.struct.php");
?>

<header class="header">
                <div class="cont-100 flex-f bkspp" id="header">
                    <div class="cont-35 mr-auto pad12">
                        <img src="https://estanciaupp.000webhostapp.com/Estancia/public/image/upp.png" alt="" class="img-logo">
                    </div>
                    <div class="cont-35 mr-auto pad12"></div>
                    <div class="cont-50 pad12 mr-auto">
                        <a href="../Estancia" class="wh apple text-d pad12 px22">Inicio</a>
                        <a href="Acerca" class="wh apple text-d pad12 px22">Acerca</a>
                        <a href="" class="wh apple text-d pad12 px22">Contactanos</a>
                        <a href="Registro" class="wh apple text-d pad6 px22 button2 radius-total">Iniciar Sesion</a>
                    </div>
                </div>
            </header>
<br><br><br>
<br><br><br>


<body>
  
    
    
    <div class ="cont-100 roboto mr-auto  ">
        <div class = "cont-100b flex-f bksil rad-le-t rad-ri-t  "> 
            <div class="cont-25 mr-auto ">
               <h1 class = " px22 cen">Usuario</h1>  
            
            </div>

            <div class="cont-25 mr-auto ">
               <h1 class = " px22 cen">Prueba</h1>  
            
            </div>

            <div class="cont-25 mr-auto ">
               <h1 class = " px22 cen">Visita</h1>  
            
            </div>

            <div class="cont-25 mr-auto ">
               <h1 class = " px22 cen">Respuesta</h1>  

            </div>

            <div class="cont-25 mr-auto">
               <h1 class=" px22 cen">Direccion</h1>
            </div>

            <div class="cont-25 mr-auto">
               <h1 class=" px22 cen">Lista</h1>
            </div>
        </div>
        <div class = "cont-100 flex-f border rad-le-b rad-ri-b"> 
            <div class="cont-25 px20 mr-auto cen ">
               <p id="id_usuario"></p>
            </div>

            <div class="cont-25 px20 mr-auto cen">
               <p id="prueba"></p>
            </div>

            <div class="cont-25 px20 mr-auto cen ">
               <p id="visita"></p>
            </div>

            <div class="cont-25 px20 mr-auto cen ">
               <p id="respuesta"></p>
            </div>

            <div class="cont-25 px20 mr-auto cen ">
               <p id="direccion"></p>
            </div>
            <div class="cont-25 px20 mr-auto cen ">
               <p id="lista"></p>
            </div>
        </div>
    </div> 
    
    
    </body>   

    
