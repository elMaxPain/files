<?php
include("updatelist.struct.php");
Init();
?>


<header class="header">
                <div class="cont-100 flex-f bkspp" id="header">
                    <div class="cont-35 mr-auto pad12">
                        <img src="https://estanciaupp.000webhostapp.com/Estancia/public/image/upp.png" alt="" class="img-logo">
                    </div>
                    <div class="cont-35 mr-auto pad12"></div>
                    <div class="cont-50 pad12 mr-auto">
                        <a href="../Estancia" class="wh apple text-d pad12 px22">Inicio</a>
                        <a href="Acerca" class="wh apple text-d pad12 px22">Acerca</a>
                        <a href="" class="wh apple text-d pad12 px22">Contactanos</a>
                        <a href="Registro" class="wh apple text-d pad6 px22 button2 radius-total">Iniciar Sesion</a>
                    </div>
                </div>
            </header>
<br><br><br>
<br><br><br>


<div class="cont-100b flex">
    <div class="cont-50 mr-auto">
        <div class="cont-100b bksil flex-f">
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Prueba</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Nivel</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Tipo</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Mas Bajo</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Mas Alto</p>
            </div>
        </div>
        <div class="cont-100b flex-f">
            <div class="cont-25 mr-auto">
                <p id="prueba1" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto">
                <p id="nivel1" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto">
                <p id="tipo1" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto">
                <p id="masbajo1" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto bkyel">
                <p id="masalto1"  class="px17 apple cen"></p>

            </div>
        </div>
    </div>
    <div class="cont-50 mr-auto ">
    <div class="cont-100b bksil flex-f">
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Prueba</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Nivel</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Tipo</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Mas Bajo</p>
            </div>
            <div class="cont-25 mr-auto">
                <p  class="px17 apple cen">Mas Alto</p>
            </div>
        </div>
        <div class="cont-100b flex-f">
            <div class="cont-25 mr-auto">
                <p id="prueba2" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto">
                <p id="nivel2" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto">
                <p id="tipo2" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto">
                <p id="masbajo2" class="px17 apple cen"></p>
            </div>
            <div class="cont-25 mr-auto bkyel">
                <p id="masalto2"  class="px17 apple cen"></p>

            </div>
        </div>
    </div>
</div>